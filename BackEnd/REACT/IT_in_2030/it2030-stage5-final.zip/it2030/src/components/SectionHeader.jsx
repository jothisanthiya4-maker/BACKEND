import useReveal from '../hooks/useReveal.js'

/**
 * Shared header used to open each major content section.
 * `index` is a real position in the page's 8-part structure, so the
 * numbering communicates sequence rather than decorating the page.
 */
export default function SectionHeader({ index, label, title, description, tone = 'signal', align = 'left' }) {
  const ref = useReveal()
  const accent = tone === 'human' ? 'text-orchid border-orchid/30' : 'text-cyan border-cyan/30'

  return (
    <div ref={ref} className={`reveal ${align === 'center' ? 'mx-auto max-w-3xl text-center' : 'max-w-3xl'}`}>
      <div className={`flex items-center gap-3 ${align === 'center' ? 'justify-center' : ''}`}>
        <span className={`flex h-8 w-8 items-center justify-center rounded-full border font-mono text-xs ${accent}`}>
          {index}
        </span>
        <span className="font-mono text-[11px] tracking-[0.3em] text-mist/45">{label}</span>
      </div>
      <h2 className="mt-5 font-display text-3xl font-bold leading-[1.15] text-mist sm:text-4xl md:text-[2.75rem]">
        {title}
      </h2>
      {description && (
        <p className="mt-4 text-base leading-relaxed text-mist/60 md:text-[1.05rem]">{description}</p>
      )}
    </div>
  )
}
